import argparse
import csv
import os
from collections import deque
from datetime import datetime, timedelta

# 라벨 id
LABEL_TO_ID = {
    "정상": 0,
    "폭염": 1,
    "한파": 2,
    "폭우": 3,
}

#임계값 설정
THRESHOLDS = {
    "heat_temp_c": 35.0,
    "cold_temp_c": -10.0,
    "heavy_rainfall_mm": 30.0,
    "high_humidity_pct": 90.0,
}

# csv 컬럼명 매핑
KMA_COLUMN_MAP = {
    "지점": "station_id",
    "지점명": "station",
    "일시": "datetime",
    "기온(°C)": "temp_c",
    "강수량(mm)": "rainfall_mm",
    "풍속(m/s)": "wind_speed_ms",
    "풍향(16방위)": "wind_dir_16",
    "습도(%)": "humidity_pct",
    "일조(hr)": "sunshine_hr",
    "일사(MJ/m2)": "solar_mj_m2",
}

# 출력 컬럼
OUTPUT_COLUMNS = [
    "datetime",
    "station_id",
    "station",
    "temp_c",
    "rainfall_mm",
    "wind_speed_ms",
    "wind_dir_16",
    "humidity_pct",
    "sunshine_hr",
    "solar_mj_m2",
    "month",
    "hour",
    "is_daytime",
    "disaster_label",
    "humidity_warning",
    "label_id",
    "target_next_24h_label",
    "target_next_24h_id",
    "temp_c_24h_mean",
    "rainfall_24h_sum",
    "wind_speed_24h_max",
    "humidity_24h_mean",
]


def read_text_with_encoding(path):
    for encoding in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            with open(path, "r", encoding=encoding, newline="") as file:
                return file.read(), encoding
        except UnicodeDecodeError:
            continue
    raise UnicodeDecodeError("unknown", b"", 0, 1, f"Cannot decode {path}")


def parse_datetime(value):
    value = (value or "").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            pass
    raise ValueError(f"Invalid datetime: {value}")


def parse_float(value, default=0.0):
    value = (value or "").strip()
    if value == "":
        return default
    return float(value)


def normalize_row(row):
    normalized = {}
    for source_name, target_name in KMA_COLUMN_MAP.items():
        normalized[target_name] = row.get(source_name, "")

    dt = parse_datetime(normalized["datetime"])
    normalized["datetime_obj"] = dt
    normalized["datetime"] = dt.strftime("%Y-%m-%d %H:%M:%S")
    normalized["station_id"] = str(normalized.get("station_id", "")).strip()
    normalized["station"] = str(normalized.get("station", "")).strip()

    for name in [
        "temp_c",
        "rainfall_mm",
        "wind_speed_ms",
        "wind_dir_16",
        "humidity_pct",
        "sunshine_hr",
        "solar_mj_m2",
    ]:
        normalized[name] = parse_float(normalized.get(name))

    normalized["month"] = dt.month
    normalized["hour"] = dt.hour
    normalized["is_daytime"] = 1 if 6 <= dt.hour <= 18 else 0
    return normalized


def classify_disaster(row):
    if row["rainfall_mm"] >= THRESHOLDS["heavy_rainfall_mm"]:
        return "폭우"
    if row["temp_c"] >= THRESHOLDS["heat_temp_c"]:
        return "폭염"
    if row["temp_c"] <= THRESHOLDS["cold_temp_c"]:
        return "한파"
    return "정상"


def classify_humidity(row):
    if row["humidity_pct"] >= THRESHOLDS["high_humidity_pct"]:
        return "고습주의"
    return "정상"


def choose_future_label(labels):
    for label in ("폭우", "폭염", "한파"):
        if label in labels:
            return label
    return "정상"


def add_rolling_features(rows):
    window = deque()
    for row in rows:
        current_dt = row["datetime_obj"]
        window.append(row)
        while window and window[0]["datetime_obj"] < current_dt - timedelta(hours=23):
            window.popleft()

        temps = [item["temp_c"] for item in window]
        rains = [item["rainfall_mm"] for item in window]
        winds = [item["wind_speed_ms"] for item in window]
        humidities = [item["humidity_pct"] for item in window]

        row["temp_c_24h_mean"] = sum(temps) / len(temps)
        row["rainfall_24h_sum"] = sum(rains)
        row["wind_speed_24h_max"] = max(winds)
        row["humidity_24h_mean"] = sum(humidities) / len(humidities)


def add_future_targets(rows, hours=24):
    for index, row in enumerate(rows):
        current_dt = row["datetime_obj"]
        end_dt = current_dt + timedelta(hours=hours)
        future_labels = []

        cursor = index + 1
        while cursor < len(rows) and rows[cursor]["datetime_obj"] <= end_dt:
            future_labels.append(rows[cursor]["disaster_label"])
            cursor += 1

        target = choose_future_label(future_labels)
        row["target_next_24h_label"] = target
        row["target_next_24h_id"] = LABEL_TO_ID[target]


def load_rows(input_paths):
    rows = []
    encodings = {}
    for path in input_paths:
        text, encoding = read_text_with_encoding(path)
        encodings[path] = encoding
        reader = csv.DictReader(text.splitlines())
        for source_row in reader:
            try:
                rows.append(normalize_row(source_row))
            except ValueError:
                continue
    rows.sort(key=lambda row: row["datetime_obj"])
    return rows, encodings


def preprocess(input_paths, output_path, target_hours=24):
    rows, encodings = load_rows(input_paths)
    if not rows:
        raise ValueError("No valid rows found.")

    for row in rows:
        row["disaster_label"] = classify_disaster(row)
        row["humidity_warning"] = classify_humidity(row)
        row["label_id"] = LABEL_TO_ID[row["disaster_label"]]

    add_rolling_features(rows)
    add_future_targets(rows, hours=target_hours)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8-sig", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()
        for row in rows:
            writer.writerow({name: row[name] for name in OUTPUT_COLUMNS})

    return {
        "row_count": len(rows),
        "file_count": len(input_paths),
        "output_path": output_path,
        "encodings": encodings,
    }


def launch_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox

    root = tk.Tk()
    root.withdraw()

    input_paths = filedialog.askopenfilenames(
        title="통합 전처리할 기상 CSV 파일 여러 개 선택",
        filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
    )
    if not input_paths:
        return

    output_path = filedialog.asksaveasfilename(
        title="하나로 합쳐 저장할 모델용 CSV 파일 이름",
        defaultextension=".csv",
        initialfile="통합_전처리_데이터셋.csv",
        filetypes=[("CSV files", "*.csv")],
    )
    if not output_path:
        return

    try:
        result = preprocess(input_paths, output_path)
    except Exception as exc:
        messagebox.showerror("전처리 실패", str(exc))
        return

    messagebox.showinfo(
        "전처리 완료",
        f"{result['file_count']}개 CSV 파일을 하나로 통합했습니다.\n"
        f"{result['row_count']}개 행을 저장했습니다.\n\n"
        f"{result['output_path']}",
    )


def parse_args():
    parser = argparse.ArgumentParser(
        description="KMA ASOS CSV files to model-ready weather disaster dataset."
    )
    parser.add_argument("input", nargs="*", help="Input CSV file paths")
    parser.add_argument("-o", "--output", help="Output CSV path")
    parser.add_argument("--target-hours", type=int, default=24, help="Future target window")
    parser.add_argument("--gui", action="store_true", help="Open file picker GUI")
    return parser.parse_args()


def main():
    args = parse_args()
    if args.gui or not args.input:
        launch_gui()
        return

    if not args.output:
        raise SystemExit("Output path is required. Use -o output.csv")

    result = preprocess(args.input, args.output, target_hours=args.target_hours)
    print(f"Saved: {result['output_path']}")
    print(f"Input files: {result['file_count']}")
    print(f"Rows: {result['row_count']}")
    for path, encoding in result["encodings"].items():
        print(f"Encoding: {path} -> {encoding}")


if __name__ == "__main__":
    main()
