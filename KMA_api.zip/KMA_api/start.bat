@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo Starting Smart Farm Map Portal...
python -m uvicorn main:app --reload

echo.
echo Server stopped. Press any key to close this window.
pause >nul
