import json
import os
import sqlite3
from urllib.parse import urlencode
from urllib.request import urlopen

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from datetime import datetime, timedelta, timezone
from pathlib import Path 



BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR
DB_PATH = BASE_DIR / "sensors.db"


def load_env():
	env_path = BASE_DIR / ".env"
	if not env_path.exists():
		return
	for line in env_path.read_text(encoding="utf-8").splitlines():
		line = line.strip()
		if not line or line.startswith("#") or "=" not in line:
			continue
		key, value = line.split("=", 1)
		os.environ.setdefault(key.strip(), value.strip())


load_env()
app = FastAPI()


app.mount("/static",StaticFiles(directory=WEB_DIR), name="static")
app.mount("/assets", StaticFiles(directory=WEB_DIR / "assets"), name="assets")

latest_sensor = {
	"distance":None,
	"created_at":None,
}

class SensorData(BaseModel):
	distance: float

def init_db():
	with sqlite3.connect(DB_PATH) as conn:
		conn.execute(
			"""
				CREATE TABLE IF NOT EXISTS sensor_logs(
					id INTEGER PRIMARY KEY AUTOINCREMENT,
					distance REAL NOT NULL,
					created_at  TEXT NOT NULL
				)
			"""
		)
		conn.commit()

def save_sensor(distance: float, created_at: str):
		with sqlite3.connect(DB_PATH) as conn:
			conn.execute(
				"INSERT INTO sensor_logs (distance, created_at) VALUES (?,?)",
				(distance, created_at),
			)
			conn.commit()


def get_sensor_history():
	with sqlite3.connect(DB_PATH) as conn:
		conn.row_factory = sqlite3.Row
		rows = conn.execute(
			"""
				SELECT id, distance, created_at
				FROM sensor_logs
				ORDER BY id DESC
				LIMIT 50
			"""
			).fetchall()
	return [dict(row) for row in rows]


def forecast_base():
	now = datetime.now(timezone(timedelta(hours=9)))
	slots = [2, 5, 8, 11, 14, 17, 20, 23]
	available = [hour for hour in slots if now.hour > hour or (now.hour == hour and now.minute >= 10)]
	if available:
		base_date = now
		base_hour = available[-1]
	else:
		base_date = now - timedelta(days=1)
		base_hour = 23
	return base_date.strftime("%Y%m%d"), f"{base_hour:02d}00"


def weather_text(sky, precipitation_type):
	if str(precipitation_type) not in ("", "0", "None"):
		return {"1": "비", "2": "비/눈", "3": "눈", "4": "소나기"}.get(str(precipitation_type), "강수")
	return {"1": "맑음", "3": "구름 많음", "4": "흐림"}.get(str(sky), "--")


def fetch_short_forecast(nx: int, ny: int):
	auth_key = os.getenv("KMA_AUTH_KEY")
	if not auth_key:
		raise HTTPException(status_code=500, detail="KMA_AUTH_KEY가 설정되지 않았습니다.")
	base_date, base_time = forecast_base()
	query = urlencode({
		"pageNo": 1,
		"numOfRows": 1000,
		"dataType": "JSON",
		"base_date": base_date,
		"base_time": base_time,
		"nx": nx,
		"ny": ny,
		"authKey": auth_key,
	})
	url = "https://apihub.kma.go.kr/api/typ02/openApi/VilageFcstInfoService_2.0/getVilageFcst?" + query
	try:
		with urlopen(url, timeout=15) as response:
			payload = json.loads(response.read().decode("utf-8"))
	except Exception as exc:
		raise HTTPException(status_code=502, detail=f"기상청 API 호출 실패: {exc}") from exc

	header = payload.get("response", {}).get("header", {})
	if header.get("resultCode") not in (None, "00"):
		raise HTTPException(status_code=502, detail=header.get("resultMsg", "기상청 API 오류"))
	items = payload.get("response", {}).get("body", {}).get("items", {}).get("item", [])
	if not items:
		raise HTTPException(status_code=502, detail="단기예보 데이터가 없습니다.")

	now = datetime.now(timezone(timedelta(hours=9)))
	now_code = now.strftime("%Y%m%d%H00")
	future_items = [item for item in items if item["fcstDate"] + item["fcstTime"] >= now_code]
	target_item = min(future_items or items, key=lambda item: item["fcstDate"] + item["fcstTime"])
	target_date = target_item["fcstDate"]
	target_time = target_item["fcstTime"]
	values = {
		item["category"]: item["fcstValue"]
		for item in items
		if item["fcstDate"] == target_date and item["fcstTime"] == target_time
	}
	precipitation = values.get("PCP", "--")
	if precipitation == "강수없음":
		precipitation = "0 mm"
	return {
		"condition": weather_text(values.get("SKY"), values.get("PTY")),
		"temperature": values.get("TMP"),
		"humidity": values.get("REH"),
		"precipitation": precipitation,
		"forecastAt": f"{target_date} {target_time}",
		"source": "기상청 단기예보",
	}

@app.on_event("startup")
def startup():
	init_db()






@app.get("/")
def home():
	return FileResponse(WEB_DIR/"main.html")


@app.get("/main.html")
def main_page():
	return FileResponse(WEB_DIR/"main.html")


@app.get("/sub_html/main.html")
def sub_main_page():
	return FileResponse(WEB_DIR/"main.html")


@app.get("/sub_html/{page_name}.html")
def sub_page(page_name: str):
	file_path = WEB_DIR / "sub_html" / f"{page_name}.html"

	if not file_path.exists():
		raise HTTPException(status_code=404, detail="Sub page not found")
	return FileResponse(file_path)

@app.get("/sensor/history")
def sensor_history():
	return get_sensor_history()


@app.get("/api/weather")
def weather(nx: int = 81, ny: int = 75):
	return fetch_short_forecast(nx, ny)


@app.get("/sensor")
def get_sensor():
	return latest_sensor

@app.post("/sensor")
def post_sensor(data: SensorData):
	created_at = datetime.now().isoformat()

	latest_sensor["distance"] = data.distance
	latest_sensor["created_at"] = created_at
	save_sensor(data.distance, created_at)

	return {
		"status": "saved",
		"data": latest_sensor,
	}
