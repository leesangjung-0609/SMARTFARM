SmartFarm 대한민국 지도 포털

실행 시작 파일: main.html

- sangju_pi.html: 상주 Raspberry Pi 실시간 운영 페이지
- index.html: 기본 환경
- heavy_rain.html: 폭우
- storm.html: 폭풍
- drought.html: 가뭄
- cold_wave.html: 한파
- fire.html: 화재

모든 파일은 같은 폴더에 두어야 링크가 정상 동작합니다.
라즈베리 Pi에서는 이 폴더를 정적 웹 폴더로 제공하고 /api/status 등의 API를 구현하세요.
